# ItemCf基于项目的协同过滤推荐实现 

关于推荐系统的介绍见博客：http://blog.csdn.net/u012050154/article/details/52267712   

ItemCF.py是代码实现   
ItemCF.png是程序运行结果    


